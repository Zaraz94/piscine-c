/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   colle.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: qumaujea <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/17 16:50:08 by qumaujea          #+#    #+#             */
/*   Updated: 2016/09/17 16:51:24 by qumaujea         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef COLLE_H
# define COLLE_H

char	*colle_00(int x, int y);
char	*colle_01(int x, int y);
char	*colle_02(int x, int y);
char	*colle_03(int x, int y);
char	*colle_04(int x, int y);

#endif

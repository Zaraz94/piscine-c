/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   colle-00.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: qumaujea <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/17 14:21:31 by qumaujea          #+#    #+#             */
/*   Updated: 2016/09/17 17:01:39 by qumaujea         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ft.h"

char	*colle_04(int x, int y, char *buf)
{
	int 	i;
	int 	j;
	char	**tab

	i = 1;
	j = 1;
	tab[y][x] = (char*)malloc(char) * ((x * y) + y);
	while (j < y)
	{
		while (i < x)
		{
			i = 1;
			if ((i == 1 && j == 1) || (i == x && j == y))
				tab[j][x] = 'A'
			if ((i > 1 && i < x) && (j == 1 || j == y))
				tab[j][x] = 'B'
			if ((i == 1 || i == x) && (j > 1 || j < y))
				tab[j][x] = 'B'
			if ((i > 1 || i < x) && (j > 1 || j < y))
				tab[j][x] = ' '
			if ((i == x && j == 1) || (i == 1 && j == y))
				tab[j][x] = 'C'
			i++;
		}
		j++;
		tab[y][j] = '\n';
	}
}

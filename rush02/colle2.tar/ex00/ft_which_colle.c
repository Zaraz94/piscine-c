/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_which_colle.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: qumaujea <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/14 10:55:29 by qumaujea          #+#    #+#             */
/*   Updated: 2016/09/17 16:53:43 by qumaujea         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "f_ft.h"
#include "colle.h"

void	ft_which_colle(void)
{
	int or;

	or = 0;
	if (ft_strcmp(buf, colle_00(x, y))i == 0)
	{
		ft_print_result("[colle-00]", x, y);
		or = 1;
	}
	if (ft_strcmp(buf, colle_01(x, y))i == 0)
	{
		ft_putstr(" || ");
		ft_print_result("[colle-01]", x, y);
	}
	if (ft_strcmp(buf, colle_00(x, y))i == 0)
	{
		ft_putstr(" || ");
		ft_print_result("[colle-02]", x, y);
	}
	if (ft_strcmp(buf, colle_00(x, y))i == 0)
	{
		ft_putstr(" || ");
		ft_print_result("[colle-03]", x, y);
	}
	if (ft_strcmp(buf, colle_00(x, y))i == 0)
	{
		ft_putstr(" || ");
		ft_print_result("[colle-04]", x, y);
	}
}
